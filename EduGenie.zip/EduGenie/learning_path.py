"""
learning_path.py — Learning Recommendations module (powered by Gemini 1.5 Pro)

Generates a personalized, structured learning path (beginner to advanced)
for a given topic, complete with resource suggestions.
"""

import os
import google.generativeai as genai

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

_model = genai.GenerativeModel("gemini-1.5-pro") if GEMINI_API_KEY else None


def get_learning_recommendations(topic: str) -> str:
    """
    Builds a detailed prompt asking Gemini to produce a structured learning
    path (beginner -> advanced) for `topic`, with suggested resources such
    as videos, articles, or books.
    """
    if not topic or not topic.strip():
        return "Please enter a topic to get a learning path for."

    if _model is None:
        return "Error: GEMINI_API_KEY is not set. Add it to your .env file."

    prompt = (
        f"Create a personalized, structured learning path for someone who "
        f"wants to learn '{topic}'. Organize it from beginner to advanced, "
        "with clear stages/timelines, and suggest useful resources "
        "(videos, articles, or books) for each stage. Keep it practical "
        "and easy to follow."
    )

    try:
        response = _model.generate_content(prompt)
        return response.text.strip() if response and response.text else \
            "Sorry, I couldn't generate a learning path for that topic."
    except Exception as e:
        return f"Error while generating learning path: {e}"
