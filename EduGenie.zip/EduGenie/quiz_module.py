"""
quiz_module.py — Quiz Generation module (powered by Gemini 1.5 Pro)

Generates 3 multiple-choice questions (4 options each) from a topic or
passage, returned as structured JSON.
"""

import os
import json
import re
import google.generativeai as genai

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

_model = genai.GenerativeModel("gemini-1.5-pro") if GEMINI_API_KEY else None


def clean_json_block(text: str) -> str:
    """Strips Markdown code-fence wrappers (```json ... ```) from a model reply."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(topic_or_passage: str):
    """
    Returns a list of 3 quiz question dicts:
    [{ "question": str, "options": [str, str, str, str], "answer": str }, ...]
    or a dict with an "error" key if generation/parsing failed.
    """
    if not topic_or_passage or not topic_or_passage.strip():
        return {"error": "Please enter a topic or passage to generate a quiz from."}

    if _model is None:
        return {"error": "GEMINI_API_KEY is not set. Add it to your .env file."}

    prompt = (
        "You are a quiz generator for a learning app. Based on the passage or "
        "topic below, create exactly 3 multiple-choice questions, each with "
        "4 options and one correct answer. "
        "Respond ONLY with valid JSON, in this exact structure, no extra text:\n"
        '[{"question": "...", "options": ["A", "B", "C", "D"], "answer": "..."}, ...]\n\n'
        f"Topic/Passage: {topic_or_passage}"
    )

    try:
        response = _model.generate_content(prompt)
        raw_text = response.text if response and response.text else ""
        cleaned = clean_json_block(raw_text)
        quiz = json.loads(cleaned)
        return quiz
    except json.JSONDecodeError as e:
        return {"error": f"Could not parse quiz JSON from the model response: {e}"}
    except Exception as e:
        return {"error": f"Error while generating quiz: {e}"}
