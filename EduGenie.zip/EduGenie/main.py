"""
main.py — EduGenie FastAPI application

Wires up the HTML frontend and 5 RESTful endpoints:
  /qa                    -> qna.py
  /explain               -> explanation_module.py
  /quiz                  -> quiz_module.py
  /summarize             -> summary_module.py
  /learn/recommendations -> learning_path.py
"""

from dotenv import load_dotenv
load_dotenv()  # reads GEMINI_API_KEY from .env before modules import genai

from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from qna import get_answer
from explanation_module import explain_concept
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations

app = FastAPI(title="EduGenie", description="Google Gemini Powered Learning Assistant")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "result": None, "task": None})


@app.post("/qa", response_class=HTMLResponse)
async def qa_endpoint(request: Request, user_input: str = Form(...)):
    answer = get_answer(user_input)
    return templates.TemplateResponse(
        "index.html", {"request": request, "result": answer, "task": "qa", "user_input": user_input}
    )


@app.post("/explain", response_class=HTMLResponse)
async def explain_endpoint(request: Request, user_input: str = Form(...)):
    explanation = explain_concept(user_input)
    return templates.TemplateResponse(
        "index.html", {"request": request, "result": explanation, "task": "explain", "user_input": user_input}
    )


@app.post("/quiz", response_class=HTMLResponse)
async def quiz_endpoint(request: Request, user_input: str = Form(...)):
    quiz = generate_quiz(user_input)
    return templates.TemplateResponse(
        "index.html", {"request": request, "result": quiz, "task": "quiz", "user_input": user_input}
    )


@app.post("/summarize", response_class=HTMLResponse)
async def summarize_endpoint(request: Request, user_input: str = Form(...)):
    summary = summarize_text(user_input)
    return templates.TemplateResponse(
        "index.html", {"request": request, "result": summary, "task": "summarize", "user_input": user_input}
    )


@app.post("/learn/recommendations", response_class=HTMLResponse)
async def learn_endpoint(request: Request, user_input: str = Form(...)):
    path = get_learning_recommendations(user_input)
    return templates.TemplateResponse(
        "index.html", {"request": request, "result": path, "task": "learn", "user_input": user_input}
    )
