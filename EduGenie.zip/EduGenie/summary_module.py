"""
summary_module.py — Summarization module (powered by Gemini 1.5 Pro)

Condenses long educational passages into concise, easy-to-understand
summaries for quick revision.
"""

import os
import google.generativeai as genai

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

_model = genai.GenerativeModel("gemini-1.5-pro") if GEMINI_API_KEY else None


def summarize_text(passage: str) -> str:
    """
    Summarizes a long passage into a concise, clear version, retaining
    the core information while removing redundancy.
    """
    if not passage or not passage.strip():
        return "Please enter some text to summarize."

    if _model is None:
        return "Error: GEMINI_API_KEY is not set. Add it to your .env file."

    prompt = (
        "Summarize the following educational passage into a concise, "
        "easy-to-understand version suitable for quick revision. "
        "Retain the key information and remove redundancy.\n\n"
        f"Passage:\n{passage}\n\nSummary:"
    )

    try:
        response = _model.generate_content(prompt)
        return response.text.strip() if response and response.text else \
            "Sorry, I couldn't generate a summary for that passage."
    except Exception as e:
        return f"Error while generating summary: {e}"
