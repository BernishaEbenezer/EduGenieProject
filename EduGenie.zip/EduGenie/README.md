# EduGenie — Google Gemini Powered Learning Assistant

A lightweight AI-powered educational assistant. Ask questions, get simplified
explanations, generate quizzes, summarize passages, and get personalized
learning paths — built with **FastAPI** + a simple **HTML/CSS** frontend.

## Project structure

```
EduGenie/
├── main.py                 # FastAPI app & routes
├── qna.py                  # Q&A module (Gemini 1.5 Pro)
├── explanation_module.py   # Concept explanation (local LaMini-Flan-T5-783M)
├── quiz_module.py           # Quiz generation (Gemini 1.5 Pro, JSON output)
├── summary_module.py        # Summarization (Gemini 1.5 Pro)
├── learning_path.py          # Learning path recommendations (Gemini 1.5 Pro)
├── templates/
│   └── index.html           # Frontend (task dropdown, textarea, submit)
├── static/
│   └── style.css             # Styling
├── requirements.txt
├── .env.example
└── README.md
```

## 1. Prerequisites

- **Python 3.10+**
- A **Google Gemini API key** — get one free at
  https://ai.google.dev/gemini-api/docs/api-key

## 2. Setup

```bash
# from inside the EduGenie/ folder
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

> **Note on `explanation_module.py`:** it uses the local model
> `MBZUAI/LaMini-Flan-T5-783M` via `transformers`/`torch`. The first time you
> call `/explain`, it will download the model (~800 MB) from Hugging Face, so
> you need internet access for that one-time download; after that it runs
> fully offline/locally (CPU is fine, works on Mac M1).

Copy the env template and add your key:

```bash
cp .env.example .env
# then edit .env and paste your real GEMINI_API_KEY
```

## 3. Run it

```bash
uvicorn main:app --reload
```

Open **http://127.0.0.1:8000** in your browser.

## 4. Using it

Pick a task from the dropdown, type your input, and submit:

| Task | Endpoint | What it does |
|---|---|---|
| Ask a Question | `POST /qa` | General Q&A |
| Explain a Concept | `POST /explain` | Simplified explanation (local model) |
| Generate Quiz | `POST /quiz` | 3 MCQs (4 options each) as structured JSON |
| Summarize Text | `POST /summarize` | Concise summary of a passage |
| Recommend Learning Path | `POST /learn/recommendations` | Beginner→advanced roadmap with resources |

## 5. Troubleshooting

- **"GEMINI_API_KEY is not set"** — make sure `.env` exists (not just
  `.env.example`) and contains a valid key, and that you restarted `uvicorn`
  after adding it.
- **`/explain` is slow the first time** — that's the one-time model download;
  subsequent calls are fast.
- **`google-generativeai` deprecation warning** — Google is migrating to a
  newer `google-genai` SDK. The code here still works, but if you want to
  future-proof it, the migration mainly touches the `genai.configure(...)` /
  `GenerativeModel(...)` calls in `qna.py`, `quiz_module.py`,
  `summary_module.py`, and `learning_path.py`.

## 6. Next steps (from the project's roadmap)

Voice interaction, multilingual support, a mobile app, progress-tracking
dashboards, gamification, LMS integration (Moodle/Google Classroom), and
image/PDF input for doubt-solving are all natural extensions.
