"""
qna.py — Question & Answer module (powered by Gemini 1.5 Pro)

Handles general knowledge / academic questions with concise, accurate answers.
"""

import os
import google.generativeai as genai

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

_model = genai.GenerativeModel("gemini-1.5-pro") if GEMINI_API_KEY else None


def get_answer(question: str) -> str:
    """
    Sends the student's question to Gemini 1.5 Pro and returns a
    smart, concise answer.
    """
    if not question or not question.strip():
        return "Please enter a question."

    if _model is None:
        return "Error: GEMINI_API_KEY is not set. Add it to your .env file."

    prompt = (
        "You are EduGenie, a helpful educational assistant. "
        "Answer the student's question clearly and concisely, "
        "in a way that is easy to understand.\n\n"
        f"Question: {question}\n\nAnswer:"
    )

    try:
        response = _model.generate_content(prompt)
        return response.text.strip() if response and response.text else \
            "Sorry, I couldn't generate an answer for that question."
    except Exception as e:
        return f"Error while generating answer: {e}"
