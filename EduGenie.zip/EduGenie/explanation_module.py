"""
explanation_module.py — Concept Explanation module
Powered by LaMini-Flan-T5-783M (runs locally, CPU-friendly, no API key needed).

The model is loaded lazily on first use so the app starts up fast and only
pays the (one-time, ~800MB) download/load cost when a user actually asks
for an explanation.
"""

from functools import lru_cache

MODEL_NAME = "MBZUAI/LaMini-Flan-T5-783M"

_pipeline = None


def _load_pipeline():
    """Lazily load the local text2text-generation pipeline."""
    global _pipeline
    if _pipeline is None:
        from transformers import pipeline
        _pipeline = pipeline(
            "text2text-generation",
            model=MODEL_NAME,
            device=-1,  # CPU; change to 0 if you have a CUDA GPU
        )
    return _pipeline


def explain_concept(topic: str) -> str:
    """
    Generates a simplified, easy-to-read explanation of `topic` using the
    local LaMini-Flan-T5 model.
    """
    if not topic or not topic.strip():
        return "Please enter a topic to explain."

    prompt = (
        f"Explain the concept of '{topic}' in simple terms for a student. "
        "Keep it clear, concise, and beginner-friendly."
    )

    try:
        pipe = _load_pipeline()
        result = pipe(prompt, max_length=256, do_sample=False)
        return result[0]["generated_text"].strip()
    except Exception as e:
        return (
            "Error while generating explanation. Make sure the model "
            f"'{MODEL_NAME}' can be downloaded (needs internet on first "
            f"run) and that `transformers`/`torch` are installed. Details: {e}"
        )
